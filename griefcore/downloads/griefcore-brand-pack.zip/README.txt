GriefCore — медиа-материалы.

logo-official.png — официальный логотип
logo.png — логотип сайта
