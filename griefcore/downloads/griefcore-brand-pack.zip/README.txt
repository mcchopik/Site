GriefCore — медиа-материалы.

logo-official.png — официальный логотип
