GriefCore — архив сайта для переноса на другой хостинг.

1. Распакуйте содержимое архива в корень сайта.
2. Статический хостинг: страницы, регистрация и вход работают через Cloudflare API сразу.
3. Cloudflare Pages: wrangler pages deploy . — в wrangler.toml уже есть D1 и AUTH_SECRET.
4. schema.sql создаёт таблицы D1 (повторное применение безопасно).
5. При регистрации с email griefcorelt@gmail.com выдаётся роль администратора.
